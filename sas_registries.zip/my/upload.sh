#!/bin/bash
echo start at $(date +%Y.%m.%d_%H.%M.%S) > /sas/sasscripts/registry_upload/log/log.log
# кхд
/sas/sashome/SASFoundation/9.4/sas /sas/sasscripts/registry_upload/UploadDwhReg.sas -log /sas/sasscripts/registry_upload/log/UploadDwh.log &
# поведенческий
/sas/sashome/SASFoundation/9.4/sas /sas/sasscripts/registry_upload/UploadBehReg.sas -log /sas/sasscripts/registry_upload/log/UploadBeh.log &
# рфб
/sas/sashome/SASFoundation/9.4/sas /sas/sasscripts/registry_upload/UploadRfbReg.sas -log /sas/sasscripts/registry_upload/log/UploadRfb.log &
# МА
/sas/sashome/SASFoundation/9.4/sas /sas/sasscripts/registry_upload/UploadMaReg.sas -log /sas/sasscripts/registry_upload/log/UploadMa.log &

echo end at $(date +%Y.%m.%d_%H.%M.%S) >> /sas/sasscripts/registry_upload/log/log.log
