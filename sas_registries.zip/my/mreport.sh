#!/bin/bash
dtstamp=$(date +%Y.%m.%d_%H.%M.%S)
pgmname="/sas/reporttest/mailreport.sas"
logname="/sas/reporttest/log/mailreport_$dtstamp.log"
/sas/sashome/SASFoundation/9.4/sas $pgmname -log $logname
